import { createClient } from '@supabase/supabase-js';

// 从环境变量读取配置（推荐）
const supabaseUrl = https://buipvrvhsuwcysuyiscq.supabase.co;
const supabaseKey = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ1aXB2cnZoc3V3Y3lzdXlpc2NxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDMwNTUzMjcsImV4cCI6MjA1ODYzMTMyN30.LrRwLJpn_OH6ACawfCjBUVNNtju9xBPo4FdkZfWHUy4;

// 或直接填写（仅用于测试）
// const supabaseUrl = 'https://[project-ref].supabase.co';
// const supabaseKey = 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseKey);