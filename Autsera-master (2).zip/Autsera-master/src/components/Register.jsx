// src/components/Register.jsx
import { supabase } from '../lib/supabase';

const Register = () => {
  const handleRegister = async (email, password) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
    });
    if (error) alert(error.message);
    else alert('注册成功，请检查邮箱验证！');
  };

  // 表单类似登录组件，调用 handleRegister 即可
};