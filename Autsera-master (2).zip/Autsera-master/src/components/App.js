import React from 'react';
import React, { useState, useEffect } from "react";
import "./App.scss";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import HomePage from "./HomePage/HomePage";
import HelpPage from "./HelpPage/HelpPage";
import MapPage from "./MapPage/MapPage";
import PlacePage from "./PlacePage/PlacePage";
import InteractionPage from "./InteractionPage/InteractionPage";
import FourOFour from "./FourOFour/FourOFour";
import React, { useState } from "react";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase";

const Auth = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      alert("登录成功！");
    } catch (error) {
      alert("登录失败：" + error.message);
    }
  };

  const handleSignUp = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      alert("注册成功！");
    } catch (error) {
      alert("注册失败：" + error.message);
    }
  };

  return (
    <div>
      <input
        type="email"
        placeholder="邮箱"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="密码"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>登录</button>
      <button onClick={handleSignUp}>注册</button>
    </div>
  );
};


function App() {
  const [completed, setCompleted] = useState(
    JSON.parse(localStorage.getItem("completed")) || []
  );

  useEffect(() => {
    try {
      localStorage.setItem("completed", JSON.stringify(completed));
    } catch (error) {
      console.error(error);
    }
  }, [completed]);

  return (
    <div className="App">
      <Router>
        <Switch>
          <Route
            exact
            path="/"
            render={({ history }) => (
              <HomePage history={history} setCompleted={setCompleted} completed={completed}/>
            )}
          />
          <Route exact path="/help" component={HelpPage} />
          <Route
            exact
            path="/map"
            render={() => (
              <MapPage completed={completed} setCompleted={setCompleted} />
            )}
          />
          <Route
            path="/place/:id"
            render={({ match }) => (
              <PlacePage
                id={Number(match.params.id)}
                completed={completed}
                setCompleted={setCompleted}
              />
            )}
          />
          <Route
            path="/interaction/:id"
            render={({ match }) => (
              <InteractionPage
                id={Number(match.params.id)}
                setCompleted={setCompleted}
              />
            )}
          />
          <Route path="*" component={FourOFour} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
